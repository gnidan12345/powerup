# Simple Trello Power-Up

A minimal Trello Power-Up example.

## How to Use

1. Upload `trello-connector.html` to any HTTPS hosting (Netlify, GitHub Pages, etc.)

2. Go to https://trello.com/power-ups/admin

3. Create a new Power-Up

4. Set **Iframe Connector URL** to: `https://your-site.com/trello-connector.html`

5. Enable capabilities:
   - Card Buttons
   - Card Badges

6. Add the Power-Up to your Trello board

## What It Does

- Adds a "Hello World" button to cards
- Shows a simple blue badge on cards
- Displays an alert when button is clicked

## Customize

Edit the `trello-connector.html` file to add your own functionality.
